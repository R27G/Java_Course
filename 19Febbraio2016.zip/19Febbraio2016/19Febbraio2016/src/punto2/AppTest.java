package punto2;

import java.time.LocalDate;
import java.util.ArrayList;

import punto1.Appartamento;
import punto1.Categoria;
import punto1.Certificato;
import punto1.Immobile;
import punto1.Indirizzo;

public class AppTest {

	public static void main(String[] args) {

			
			Certificato c1 = new Certificato(LocalDate.of(2020, 10, 3), Categoria.A);
			Certificato c2 = new Certificato(LocalDate.of(2019, 4, 3), Categoria.C);
			Certificato c3 = new Certificato(LocalDate.of(2001, 7, 27), Categoria.D);
			Certificato c4 = new Certificato(LocalDate.of(1999, 11, 5), Categoria.A);
			Certificato c5 = new Certificato(LocalDate.of(2020, 3, 16), Categoria.E);
			
			Indirizzo i1 = new Indirizzo("Battipaglia", 84091, "Via Roma", 4);
			Indirizzo i2 = new Indirizzo("Salerno", 93202, "Via Mantova", 6);
			Indirizzo i3 = new Indirizzo("Napoli", 84912, "Via Potenza", 10);
			Indirizzo i4 = new Indirizzo("Battipaglia", 84091, "Via Belvedere", 32);
			Indirizzo i5 = new Indirizzo("Pontecagnano", 84094, "Via Piacenza", 4);
			
			Appartamento a1 = new Appartamento(i1, "Appartamento elegante", 200.000, 5, 6, c1);
			Appartamento a2 = new Appartamento(i2, "Appartamento casual", 150.000, 5, 7, c2);
			Appartamento a3 = new Appartamento(i3, "Appartamento malandato", 100.000, 4, 6, c3);
			Appartamento a4 = new Appartamento(i4, "Appartamento sociale", 50.000, 1, 5, c4);
			Appartamento a5 = new Appartamento(i5, "Appartamento grande", 500.000, 1, 10, c5);

			ArrayList<Appartamento> listAppartamenti = new ArrayList<Appartamento>();
			listAppartamenti.add(a1);
			listAppartamenti.add(a2);
			listAppartamenti.add(a3);
			listAppartamenti.add(a4);
			listAppartamenti.add(a5);
			
			Extract<Appartamento> estrattoreAppartamenti = new Extract<Appartamento>() {

				@Override
				public String estrai(ArrayList<Appartamento> list) {
					String res = "";
					for(Appartamento a: list) {
						res += "\n"+a.getStanze()+" "+a.getPrezzo()+" "+a.getCertificato().getCategoria();
					}
					return res;
				}
			};
			System.out.println("Informazioni da classe anonima: "+estrattoreAppartamenti.estrai(listAppartamenti));
			
			ArrayList<Indirizzo> listIndirizzi = new ArrayList<Indirizzo>();
			listIndirizzi.add(i1);
			listIndirizzi.add(i2);
			listIndirizzi.add(i3);
			listIndirizzi.add(i4);
			listIndirizzi.add(i5);
			ExtractIndirizzi estrattoreIndirizzi = new ExtractIndirizzi();
			System.out.println("Informazioni da classe interna: "+estrattoreIndirizzi.estrai(listIndirizzi));
			
			ArrayList<Immobile> listImmobili = new ArrayList<Immobile>();
			Immobile immobile1 = a1;
			Immobile immobile2 = a2;
			Immobile immobile3 = a3;
			
			
			listImmobili.add(immobile1);
			listImmobili.add(immobile2);
			listImmobili.add(immobile3);
			
			if(immobile1.search(listImmobili)) {
				System.out.println("Ricerca immobile [Punto 3] avvenuta con successo.");
			}
			
			Extract<Immobile> estrattoreImmobili = (list) -> {
				String res = "";
				for(Immobile i : list) {
					res += "\n"+i.getDescrizione();
				}
				return res;
			};
			
			System.out.println("Informazioni da espressione lamda: "+estrattoreImmobili.estrai(listImmobili));
			
	}

	public static class ExtractIndirizzi implements Extract<Indirizzo>{

		@Override
		public String estrai(ArrayList<Indirizzo> list) {
			String res = "";
			for(Indirizzo i : list) {
				res += "\n"+i.getCap()+" "+i.getCittà()+" "+i.getCivico()+" "+i.getVia();
			}
			return res;
		}
	}
	
}
