package punto1;

public enum Categoria {
	A,
	B,
	C,
	D,
	E
}
