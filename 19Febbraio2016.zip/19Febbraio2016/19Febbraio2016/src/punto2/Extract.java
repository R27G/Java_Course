package punto2;

import java.util.ArrayList;

import punto1.Appartamento;

public interface Extract<T> {
	String estrai(ArrayList<T> list);

}
