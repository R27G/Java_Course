package punto1;

import java.time.LocalDate;

public final class Certificato {
	private LocalDate dataEmissione;
	private Categoria categoria;
	
	public Certificato(LocalDate d, Categoria c) {
		dataEmissione = d;
		categoria = c;
	}

	//Metodi modificatori
	public LocalDate getDataEmissione() {
		return dataEmissione;
	}

	public Categoria getCategoria() {
		return categoria;
	}
	
	public String toString() {
		return this.getClass().getName()+"[Data Emissione: "+dataEmissione
				+" Categoria: "+categoria+"]";
	}
	
	public boolean equals(Object obj) {
		if(obj == null) return false;
		
		if(obj.getClass() != getClass()) return false;
		
		Certificato c = (Certificato) obj;
		
		return (c.getCategoria() == categoria && c.getDataEmissione().equals(dataEmissione));
	}
	
}
