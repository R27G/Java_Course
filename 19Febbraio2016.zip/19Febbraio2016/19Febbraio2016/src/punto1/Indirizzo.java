package punto1;

public class Indirizzo implements Cloneable{
	private String città;
	private int cap;
	private String via;
	private int civico;
	
	public Indirizzo(String c, int c2, String via, int c3) {
		città = c;
		cap = c2;
		this.via = via;
		civico = c3;
	}
	
	//Metodi d'accesso
	public String getCittà() {
		return città;
	}

	public int getCap() {
		return cap;
	}

	public String getVia() {
		return via;
	}

	public int getCivico() {
		return civico;
	}

	//Metodi modificatori
	public void setCittà(String città) {
		this.città = città;
	}

	public void setCap(int cap) {
		this.cap = cap;
	}

	public void setVia(String via) {
		this.via = via;
	}

	public void setCivico(int civico) {
		this.civico = civico;
	}
	
	public String toString() {
		return this.getClass().getName()+" [Città: "+città+" Cap: "+cap
				+" Via: "+via+" Civico: "+civico;
	}
	
	public boolean equals(Object obj) {
		if(obj == null) return false;
		
		if(obj.getClass() != getClass()) return false;
		
		Indirizzo i = (Indirizzo) obj;
		
		return (i.getCap() == cap && i.getCittà().equals(città) && i.getCivico() == civico && i.getVia().equals(via));
	}
	
	public Indirizzo clone() {
		try {
			return (Indirizzo) super.clone();
		}catch(CloneNotSupportedException e) {
			return null;
		}
	}
	
}
