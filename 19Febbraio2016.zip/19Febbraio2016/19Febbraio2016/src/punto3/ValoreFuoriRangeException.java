package punto3;

public class ValoreFuoriRangeException extends Exception{

}
