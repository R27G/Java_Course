package punto3;

public class ImmobileNonTrovatoException extends RuntimeException{

}
