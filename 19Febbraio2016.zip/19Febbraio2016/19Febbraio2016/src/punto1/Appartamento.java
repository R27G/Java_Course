package punto1;

import java.util.ArrayList;

import punto3.ImmobileNonTrovatoException;

public class Appartamento extends Immobile{

	private int piano;
	private int stanze;
	private Certificato certificato;
	
	public Appartamento(Indirizzo i, String d, double p, int piano, int stanze, Certificato c) {
		super(i, d, p);
		this.piano = piano;
		this.stanze = stanze;
		certificato = c;
	}
	
	//Metodi modificatori
	public void setPiano(int piano) {
		this.piano = piano;
	}

	public void setStanze(int stanze) {
		this.stanze = stanze;
	}

	public void setCertificato(Certificato certificato) {
		this.certificato = certificato;
	}

	//Metodi d'accesso
	public int getPiano() {
		return piano;
	}

	public int getStanze() {
		return stanze;
	}

	public Certificato getCertificato() {
		return certificato;
	}
	
	public String getDescrizioneEClasseEnergetica() {
		return super.getDescrizione()+" "+this.getCertificato().getCategoria();
	}

	//Metodi classe Object
	public String toString() {
		return super.toString()+" [Piano: "+piano+" Stanze: "
				+" Certificato"+certificato.toString()+"]";
	}
	
	public boolean equals(Object obj) {
		if(!super.equals(obj))
			return false;
		Appartamento a = (Appartamento) obj;
		return (a.getCertificato().equals(certificato) && a.getPiano() == piano && a.getStanze() == stanze);
	}
	
	public Appartamento clone() {
		Appartamento a = (Appartamento) super.clone();
		return a;
	}


}
