package punto1;

import java.util.ArrayList;

import punto3.ImmobileNonTrovatoException;


public abstract class Immobile implements Cloneable{
	private Indirizzo indirizzo;
	private String descrizione;
	private double prezzo;
	
	public Immobile(Indirizzo i, String d, double p) {
		indirizzo = i;
		descrizione = d;
		prezzo = p;
	}

	//Metodi modificatori
	public void setIndirizzo(Indirizzo indirizzo) {
		this.indirizzo = indirizzo.clone();
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}
	
	//Metodi d'accesso
	public Indirizzo getIndirizzo() {
		return indirizzo.clone();
	}

	public String getDescrizione() {
		return descrizione;
	}

	public double getPrezzo() {
		return prezzo;
	}
	
	public String toString() {
		return getClass().getName()+" [Indirizzo: "+indirizzo.toString()
				+" Descrizione: "+descrizione+" Prezzo: "+prezzo+"]";
	}
	
	public boolean equals(Object obj) {
		if(obj == null) return false;
		
		if(obj.getClass() != getClass()) return false;
		
		Immobile i = (Immobile) obj;
		return (i.getDescrizione().equals(descrizione) && i.getIndirizzo().equals(indirizzo) && i.getPrezzo() == prezzo);
	}
	
	public Immobile clone() {
		try {
			Immobile i = (Immobile) super.clone();
			i.indirizzo = indirizzo.clone(); //Altrimenti si viola l'incapsulamento
			return i;
			
		}catch(CloneNotSupportedException e) {
			return null;
		}
	}
	
	public boolean search(ArrayList<Immobile> list) throws ImmobileNonTrovatoException{
		for(Immobile i: list) {
			if(this.equals(i))
				return true;
		}
		throw new ImmobileNonTrovatoException();
	}
	
}
